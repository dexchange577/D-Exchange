D EXCHANGE — OTP CONFIRMATION UPDATE (v8)

WHAT CHANGED IN index.html
- Added a clearly visible, full-width OTP Code tile at the top of the Admin Panel.
- The tile opens the OTP audit activity viewer.
- Corrected registration/login helper text so it no longer says OTP is not required.
- Kept the existing site's unrelated sections and files unchanged.

SUPABASE SETUP
1. Run OTP_AUDIT_SETUP.sql in Supabase SQL Editor.
2. In Supabase Authentication > Sign In / Providers > Email, enable Confirm email.
3. In Authentication > Email Templates, ensure the signup email template displays the OTP token ({{ .Token }}), not only a confirmation link.
4. Set email OTP expiry to 600 seconds (10 minutes) in Auth settings if supported.
5. Deploy the index.html from this ZIP to the same Netlify/GitHub project that serves d-exchange.net.

IMPORTANT LIMITS
- The admin OTP view reads metadata from otp_audit_logs and never stores/displays the actual OTP.
- The included SQL records Auth user creation and email-confirmation state changes. It does NOT independently record every email delivery failure or every resend attempt. Those require server-side logging in the email/OTP sender.
- The 90-second resend countdown in the browser is a usability control only; Supabase server rate limits and OTP expiry are authoritative.
- This package has not been deployed to your live site or end-to-end tested against your Supabase project from this environment.
